# Discord-get-token
Vous permet de récupérer votre token via un email et mot de passe (marrche pour les token a2f\no a2f)


pour créer le .exe vous lancez le fichier install.bat vous attendez que l'installation soit finie puis vous lancez build.bat et voila
sinon encore plus simple vous faite un clique droit sur "discord get token exe.rar" et vous faites "extraire ici"

![ScreenShot](https://media.discordapp.net/attachments/731197380732518460/777908055278092318/Capture.PNG?width=962&height=498)

![ScreenShot](https://cdn.discordapp.com/attachments/731197380732518460/777909097273884672/Capture.PNG)

![ScreenShot](https://cdn.discordapp.com/attachments/731197380732518460/777909803800068136/Capture.PNG)
